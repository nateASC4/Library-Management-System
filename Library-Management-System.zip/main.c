
#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

// array sizes immutable, define before program starts
#define numOfBooks 10000
#define numOfStudents 10000
// define size of default variables
#define nameSize 50
#define bookNameSize 50
#define descriptionSize 1500
#define issuedSize 500
//
///////////////////////////////////////////////////
//           BEGIN FUNCTION PROTOTYPES           //
//
//    Database Management    //

int initializeDatabases( const char *books, const char* descriptions, const char *issued, int current_book_index);

// Graphical User Interface //
void welcomeMessage();
void mainMenu();
//
// User Management //
void userExists();
void createUser();
void issueBook();
//
// Book Management //
void addBook(char database[numOfBooks][bookNameSize]);
void deleteBook(char database[numOfBooks][bookNameSize], char word[bookNameSize]);
void issued(char database[numOfBooks][bookNameSize],char currentIssuedBooks[numOfBooks][nameSize]);
int searchBook(char database[numOfBooks][bookNameSize], char word[bookNameSize]);
void printBooks();
void editBookRecord(char database[numOfBooks][bookNameSize],char descriptionOfBooks[numOfBooks][descriptionSize], int index);
void deleteIssued(char database[numOfBooks][nameSize], char name[bookNameSize]);
//
// Uncategorized or Temporary //

void writeToFiles(char * filename1, char * filename2);
void writeIssuedFile();

//
//            END FUNCTION PROTOTYPES            //
///////////////////////////////////////////////////
//
//            GLOBAL VARIABLES                   //
char nameDatabase[numOfStudents][nameSize], bookDatabase[numOfBooks][bookNameSize];
char currentIssuedBooks[numOfBooks][nameSize], authorOfBooks[numOfBooks][bookNameSize]; // ouch oof my bones
char descriptionOfBooks[numOfBooks][descriptionSize];
int current_book_index = 0, current_name_index = 0; 

// Main Function // 
int main(void) {
  
  // initialize databases from datafiles
  current_book_index = initializeDatabases("books.txt", "descriptions.txt", "issued.txt", current_book_index);
  // display LMS welcome message
  welcomeMessage();
  // display LMS initial menu 
  mainMenu();
}

// read input files and initialize databases
int initializeDatabases(const char *books, const char *descriptions, const char *issued, int current_book_index) {
  // initialize file pointers
  FILE *bkPtr, *dscPtr, *issPtr; // books, descriptions, issued
  
  int cbi = current_book_index; // shorter variable
  // check if books input is a valid file
  if ((bkPtr = fopen(books, "r")) == NULL) {
    puts("ERROR: File could not be opened!");
  } else {
    printf("# Initializing %s . . . ", books);
    char aString[bookNameSize];
    // while !EOF, read each line and assign to bookDatabase
    while(fgets(aString, bookNameSize, bkPtr)) {
      fscanf(bkPtr, "%[^~]~%[^\n]", bookDatabase[cbi], authorOfBooks[cbi]);
      cbi++;
    } printf("DONE\n");
  }
  fclose(bkPtr); // close books file
  rewind(bkPtr); // rewind books pointer

  // check if descriptions input is a valid file
  if ((dscPtr = fopen(descriptions, "r")) == NULL) {
    puts("ERROR: File could not be opened!");
  } else {
    printf("# Initializing %s . . . ", descriptions);
    int count = 0;
    char aString[descriptionSize];
    while(fgets(aString, descriptionSize, dscPtr)) {
      fscanf(dscPtr, "%[^\n]", descriptionOfBooks[count]);
      count++;
    } printf("DONE\n");
  } fclose(dscPtr), rewind(dscPtr); // close file and rewind pointer

  // check if issued input is a valid file
  if ((issPtr = fopen(issued, "r")) == NULL) {
    puts("ERROR: File could not be opened!");
  } else {
    printf("# Initializing %s . . . ", issued);
    int num = 0;
    char aString[issuedSize];
    while(fgets(aString, issuedSize, issPtr)) {
      if (strcmp(aString, "\n") == 0) {
        strcpy(currentIssuedBooks[num], "\0");
      } else {
        fscanf(issPtr, "%[^\n]", currentIssuedBooks[num]);
      }
      num++;
    } printf("DONE\n");
  } fclose(issPtr), rewind(issPtr); // close file and rewind pointer

  return cbi;
}

// display initial welcome message
void welcomeMessage() {
  puts("###########################################");
  puts("#                                         #");
  puts("#        LIBRARY MANAGEMENT SYSTEM        #");
  puts("#                                         #");
  puts("###########################################\n");
  printf("Press any key to continue... ");
  getchar();
  puts("");
}

// display main menu
void mainMenu() {
  int input;
  char temp;
  char sinput[500];
  puts("---------------- MAIN MENU ----------------");
  puts("- 1. Add Books\n- 2. Delete Books\n- 3. Search Books\n- 4. Issue Books\n- 5. Return books\n- 6. View Book List\n- 7. Edit Book's Record\n- 8. Close Application");
  puts("-------------------------------------------");
  printf("- Please make a selection [1-8]: ");
  scanf("%d", &input);
  puts("-------------------------------------------");
  while (input != 8) {
    if (input == 1) {
      addBook(bookDatabase);
    } else if (input == 2) {
      printf("Enter title of book to delete: ");
      scanf("%c",&temp); // temp statement to clear buffer
	    scanf("%[^\n]",sinput);
      deleteBook(bookDatabase,sinput);
    } else if (input == 3) {
      printf("Enter title of book to search: ");
      scanf("%c",&temp); // temp statement to clear buffer
	    scanf("%[^\n]",sinput);
      int free = searchBook(bookDatabase,sinput);
      if (free == -1){
        puts("The book you have entered is not in the database");
      }
      else {
        printf("%s is in location %d\n", sinput, free);
        if (strcmp(currentIssuedBooks[free], "\0") == 0){
         printf("\nBook is available\n");
        }
      }
    } else if (input == 4) {
      issued(bookDatabase, currentIssuedBooks);
    } else if(input == 5 ){
      printf("Enter your name: ");
      scanf("%c",&temp); // temp statement to clear buffer
	    scanf("%[^\n]",sinput);
      deleteIssued(currentIssuedBooks,sinput);
      }
      else if (input == 6) {
      printBooks();
    } else if (input == 7) {
      editBookRecord(bookDatabase,descriptionOfBooks,current_book_index);
    } else {
      puts("- ERROR: Invalid Input!");
      printf("- Please make a valid selection [1-8]: ");
      scanf("%d", &input);
    } 
    writeToFiles("books.txt", "descriptions.txt");

    // go back to main menu
    puts("---------------- MAIN MENU ----------------");
    puts("- 1. Add Books\n- 2. Delete Books\n- 3. Search Books\n- 4. Issue Books\n- 5. Return a Book\n- 6. View Book List\n- 7. Edit Book's Record\n- 8. Close Application");
    puts("-------------------------------------------");
    printf("- Please make a selection [1-8]: ");
    scanf("%d", &input);
    puts("-------------------------------------------");  
    } 
    exit(0); // exit if input is 8
}

void issued(char database[numOfBooks][bookNameSize],char currentIssuedBooks[numOfBooks][nameSize]) { 
  /*
  index being current_book_index
  */
  int booklocation = -1;
  char book[bookNameSize];
  char student[nameSize];
  char temp;
  char exit[2] = "0";
  
  //FIND INDEX OF BOOK IN DATA BASE/////
  while (booklocation == -1) { // allow retry for search
    printf("\nPlease enter book title [0 to exit]: ");
    scanf("%c", &temp);
    scanf("%[^\n]", book);
    if (strcmp(book, exit) == 0) { // check if 0 to exit
      mainMenu();
    }
    booklocation = searchBook(database,book);
  }
  if (strcpy(currentIssuedBooks[booklocation], "\0") == 0){
    puts("The book is unavailable!");
  }
  else{
  //ASSIGN STUDENT NAME TO SAME INDEX IN ISSUED ARRAY
  printf("\nPlease enter name of student: ");
  scanf("%c",&temp); // temp statement to clear buffer
	scanf("%[^\n]",currentIssuedBooks[booklocation]);
  printf("%s is assigned \"%s\" at location: %d\n", currentIssuedBooks[booklocation], book, booklocation);  
  }
}

// add book to database
void addBook(char database[numOfBooks][bookNameSize]){
  /*
  Adds a book to the library
  */
  char temp;
  printf("Enter title of book: ");
  scanf("%c",&temp); // temp statement to clear buffer
	scanf("%[^\n]",database[current_book_index]);
  
  printf("Enter author name: ");
  scanf("%c",&temp);
  scanf("%[^\n]",authorOfBooks[current_book_index]);
  printf("Enter description [1500 characters max]: ");
  scanf("%c",&temp);
  scanf("%[^\n]",descriptionOfBooks[current_book_index]);
  current_book_index++;
}

// search for book in database
int searchBook(char database[numOfBooks][bookNameSize], char word[bookNameSize]) {
  for (int i = 0; i < current_book_index; i++){
  if (strcmp((database[i]), word) == 0){
      return i;
    }
  } 
  return -1;
}

//delete book if library no longer has book
void deleteBook(char database[numOfBooks][bookNameSize], char word[bookNameSize]){
  int word_index = searchBook(database, word);
  if (word_index == -1){
    puts("ERROR: The book you have chosen to delete from the database is invalid!");
  }
  else{
    for (int i = word_index; i < current_book_index; i ++){
      strcpy(database[i], database[i+1]);
      strcpy(currentIssuedBooks[i],currentIssuedBooks[i+1]);
      strcpy(authorOfBooks[i],authorOfBooks[i+1]);
      strcpy(descriptionOfBooks[i], descriptionOfBooks[i+1]);
    }
  }
  current_book_index--;
}

//allows user to return books
void deleteIssued(char database[numOfBooks][nameSize], char name[bookNameSize]){
  int word_index = searchBook(database, name);
  if (word_index == -1){
    puts("ERROR: You do not have a book checked out!");
  }
  else{
    strcpy(currentIssuedBooks[word_index],"\0");
    puts("You have successfully returned a book!");
  }
}

// show all books in current database
void printBooks() {
  puts("- Library System Contains the Following Books:");
  puts("-------------------------------------------");
  for (int i=0; i<current_book_index; i++) {
    if (strlen(bookDatabase[i]) != 0) { // print only existing books
      printf("%d.) \"%s\", by %s\n", i+1, bookDatabase[i], authorOfBooks[i]);
    }
  }
  puts("-------------------------------------------\n");
}

// edit book records
void editBookRecord(char database[numOfBooks][bookNameSize],char descriptionOfBooks[numOfBooks][descriptionSize], int index)
{
  int booklocation = -1;
  char book[bookNameSize]; 
  char desc[descriptionSize];
  char temp;
  char exit[2] = "0";
  
  while (booklocation == -1) {
   printf("Enter name of book [0 to exit] : " ); 
   scanf("%c" , &temp); //to clear buffer
   scanf("%[^\n]", book);//check if book exists
   if (strcmp(book, exit) == 0) { // check if 0 to exit
    mainMenu();
   }
   booklocation = searchBook(database,book);
  }

  //ASSIGN DESCRIPITION TO SAME INDEX IN ISSUED ARRAY
  printf("Enter description [1500 characters max]: ");
  scanf("%c",&temp);//clear buffer
  scanf("%[^\n]",descriptionOfBooks[booklocation]);
  
}
// write databases to files at end of program
void writeToFiles(char *filename1, char *filename2){
  /*
  Writes the database values back to its textfiles
  Useful for when the program closes
  */
  FILE *bookfile;
  FILE *descriptionfile;
  bookfile = fopen(filename1, "w");
  descriptionfile = fopen(filename2, "w");
  fputs("Book List\n", bookfile);
  fputs("Descrptions of Books\n", descriptionfile);


  for (int i = 0; i < current_book_index; i++)
  {
  int j = 0;
  while (bookDatabase[i][j] != '\0'){
    fputc(bookDatabase[i][j], bookfile);
    j++;
  }
    
    fputc('~', bookfile);
    j = 0;
    while (authorOfBooks[i][j] != '\0'){
      fputc(authorOfBooks[i][j], bookfile);
      j++;
    }
    if (i != current_book_index - 1)
    {
      fputc('\n', bookfile);
    }
    j = 0;
    while (descriptionOfBooks[i][j] != '\0'){
      fputc(descriptionOfBooks[i][j], descriptionfile);
      j++;
    }
    if (i != current_book_index - 1)
    {
      fputc('\n', descriptionfile);
    }
  }

  fclose(bookfile);
  fclose(descriptionfile);
  writeIssuedFile();
}


void writeIssuedFile(){
  /*
  Writes to issued.txt
  Tells whether the book is issued or not 
  */
  FILE * issuedfile;
  issuedfile = fopen("issued.txt", "w");
  fputs("ISSUED LISTS (IF EMPTY, THE BOOK IS FREE)\n", issuedfile);
  for (int i = 0; i < current_book_index; i++)
  {
    if (strcmp(currentIssuedBooks[i], "\0") == 0){
      fputc('\n', issuedfile);
    } 
    else{
      int j = 0;
      //printf("%s\n", currentIssuedBooks[i]);
    while (currentIssuedBooks[i][j] != '\0'){
      fputc(currentIssuedBooks[i][j], issuedfile);
      j++;
    }
    }
  }
  fclose(issuedfile);
}


