Library Management System

  In this project you can save the name of the student with the date of issue and author of the book. 

  It also provides a facility to allocate no. Of the books that students can issue.

    1.	Issue book

    2.	Submit book

    3.	Add info for a new book

    4.	Search a book

    5.	Show Issued books for le* person and much more!!

Example Layout:

############ MAIN MENU ##########
     # 1. Add Books
     # 2. Delete Books
     # 3. Search Books
     # 4. Issue Books
     # 5. View Book List
     # 6. Edit Book's Record
     # 7. Close Application
#################################

Date and time: Thu Oct 21 15:15:30 2021

Enter your choice: 

Notes:

      Useful Libraries:

          <ctype.h> 
            About:
             https://www.tutorialspoint.com/c_standard_library/ctype_h.htm